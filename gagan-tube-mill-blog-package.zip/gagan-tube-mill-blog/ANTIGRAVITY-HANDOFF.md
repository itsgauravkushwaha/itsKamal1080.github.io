# Deploy the reviewed tube-mill article

Target repository: https://github.com/Nikolakevinzo/gagan-engineering-website

This is a content/research package, not an application patch. It does not replace the earlier SEO-fixes package. The source article is `blog-draft.md`; `article-content.json` is a draft conversion to the existing section/table format, and `seo-metadata.json` describes intended metadata. Research and strategy files are internal planning material, not public site pages.

## Current facts and pending inputs

The owner confirmed that 1.5 inch and 3 inch refer to outside diameter and that round, square and rectangular configurations can be customized. The quotation PDF, original pictures and running video have not been received here. Do not invent machine ranges, wall thickness, materials, welding process, speed/output, price, certifications, warranty, installations or author credentials.

Keep the post as an editorial draft until the owner supplies/reviews the configuration facts and media. All null author/date/image/video fields must be resolved honestly before publication, not filled with fabricated values. If the owner elects to publish a general buying guide without model-specific data, retain the article's careful scope and make that choice explicit; do not convert the examples into machine claims.

When a quotation arrives, identify which model/configuration it covers. Extract relevant engineering scope, redact customer/contact/commercial details and do not publish the PDF itself or private pricing. Ask for clarification if the quotation conflicts with the OD-label statement. One configuration's quotation does not define both mills. Preserve the general buying advice, then add a quote-backed matrix and genuine Gagan evidence where available.

## Repository and scope

1. Inspect Git status, origin and current files. If the Windows project was downloaded as a ZIP and has no `.git`, clone the target repository into a separate folder rather than starting a disconnected history. Preserve existing work.
2. Check whether the earlier publishing/crawler/schema/enquiry fixes are already present and deployed. Reconcile with current origin/main without resetting or force pushing.
3. Convert the reviewed Markdown or use the supplied draft section/table JSON, checking every paragraph, table, FAQ and internal link. Follow the repository's actual BlogCreate/seed schema; the JSON's null editorial fields mean it must not be imported unchanged as a published record.
4. Keep API seeds, local backend seeds and frontend source data consistent where those stores are still used. Use supported durable publication APIs if that is the established workflow; do not write to a live database or public article without the owner's deployment instruction.
5. Make the proposed blog category `Tube Mills & Pipe Manufacturing` / `tube-mills` work in the listing and admin filters. Inspect current taxonomy; do not mix blog category IDs with product category IDs.
6. The live catalogue reviewed here had no dedicated tube-mill model pages. Recheck current production and existing routes. Use genuine existing URLs when present. New product pages need approved specifications and their own review; never invent model pages or fill them with guessed capacity tables just to house keywords.

## Public page and assets

- Slug: `/blog/1-5-inch-vs-3-inch-tube-mill`
- Proposed canonical: `https://www.gaganengineerings.in/blog/1-5-inch-vs-3-inch-tube-mill`
- Preserve the readable H1 and use the metadata summary. Use the shorter SEO title if the existing model supports a separate SEO title; otherwise keep a descriptive article title rather than adding a schema migration just for title length. Avoid a duplicated brand suffix.
- Use actual publication and meaningful edit dates. Choose truthful author attribution. Use an actual tube-mill hero image and original media with accurate captions; do not reuse a roofing machine image as tube-mill proof.
- Copy `assets/tube-mill-rfq-checklist.csv` to `frontend/public/downloads/tube-mill-rfq-checklist.csv`.
- Copy `assets/tube-mill-trial-record.csv` to `frontend/public/downloads/tube-mill-trial-record.csv`.
- Keep the worksheets available and linked as downloads; they are blank buyer tools, not completed acceptance certificates.
- Verify `/contact` and `/blog/industrial-machinery-export-guide-india`, and add model/hub links only after their genuine routes exist.
- Render all section/table/FAQ content for both normal readers and crawlers using the established full-content path. Keep content and publication state identical.
- The checked frontend renders section text as plain React text, so Markdown links and bold formatting currently remain literal. Make the article's internal/download/source links real accessible anchors with a minimal safe inline renderer or an existing supported renderer. Preserve escaping, allow appropriate relative/http(s) URLs, reject unsafe protocols and never inject raw article HTML. Verify bold text, links, line breaks and malicious input handling; do not introduce a new dependency if existing code suffices.
- Use truthful Article/BlogPosting and breadcrumbs where supported. Do not fabricate offers, prices, ratings, testimonials, stock or service guarantees. Current Google documentation says FAQ rich results no longer appear; visible FAQ answers remain useful to readers.
- Add video metadata only after actual video fields exist. A watch page for video-feature eligibility needs the video as its main content; an embedded supporting clip does not guarantee video indexing.
- Do not deploy the 1,148-query CSV, research files, strategy or editorial notes as website content. Do not stuff body copy, alt text, headings, hidden text, schema or meta keywords. Candidates have no verified search volumes/ranks.
- If the app serves static sitemap/LLM files, update factual article entries consistently after publication. Do not refresh unrelated lastmod dates or promise Google visibility from LLM files.

## Verification and release

Use existing dependencies; preserve manifests and lockfiles. Run relevant existing backend/crawler/publishing checks and the frontend production build, adapting shell commands for Windows. The earlier package documents those test commands. Add only a small useful content/rendering regression if needed to catch a genuine new integration risk.

Verify locally that the complete article, tables, FAQs, correct metadata, downloads, internal links and enquiry flow render; draft state remains hidden publicly until released. Use isolated fixtures for enquiry tests and do not send real test leads or change unrelated live records.

After the owner supplies/reviews the final facts/media and authorizes release, commit only intended source/assets/test changes, reconcile origin/main, and push without force pushing. Check deployment status, the live article/crawler HTML, canonical, sitemap and download responses. Submit the canonical URL through the owner's Search Console access if available and authorized; submission is not an indexing/ranking guarantee. Report commit SHA, checks, deployment status and remaining limitations.

Never commit quotations, credentials, downloaded research caches, the full keyword library, dependencies, build output or private customer data. Do not perform outreach, buy links or create bulk country pages.
