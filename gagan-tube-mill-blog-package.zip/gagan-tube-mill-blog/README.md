# Gagan tube-mill blog and SEO research package

Prepared 8 October 2026. This package is an editorial draft and deployment brief for **Nikolakevinzo/gagan-engineering-website**; it is not a deployed website change.

## Start here

1. Read [the article](blog-draft.md): a practical 1.5-inch versus 3-inch OD-label buyer guide.
2. Read [the competitor SEO strategy](competitor-seo-strategy.md) for the evidence-led actions and first 90-day plan.
3. Review [open editorial items](editorial-open-items.md), then supply the quotation and original pictures/video to the deployment workflow.
4. Give this folder to Antigravity and follow [the deployment handoff](ANTIGRAVITY-HANDOFF.md).

## What is included

- `blog-draft.md`: original buyer article, tables, FAQs, quotation comparison and clearly hypothetical production calculation.
- `article-content.json`: unpublished draft in the current section/table format. Author, date and image fields remain unresolved; do not import it as a published record.
- `seo-metadata.json`: title/summary, proposed canonical/category and editorial status.
- `keyword-map.csv`: 1,148 distinct **generated, unvalidated query candidates**, not measured search volumes or rankings. Use it for planning, not keyword stuffing.
- `keyword-priorities.md`: 50 initial candidate priorities and page-intent ownership.
- `competitor-seo-strategy.md`: specific actions grounded in reviewed manufacturer/tooling pages; no worldwide number-one guarantee.
- `research/india-competitors.md` and `research/global-competitors.md`: page-specific findings and research limits.
- `research-sources.json`: public source URLs, access dates and roles; no competitor-page copies.
- `assets/`: blank RFQ and production-trial CSV worksheets to deploy as useful downloads.
- `VALIDATION.json`: package checks and remaining inputs.

## Verified facts and limitations

The owner confirmed that 1.5-inch and 3-inch labels refer to outside diameter and that round, square and rectangular configurations can be customized. Exact conversions are 38.1 mm and 76.2 mm. The quotation PDF, original images and video have not been received. The article does not invent other machine specifications, prices, warranties or performance.

Direct pages from Rollform, Fives, Formtek and FD Machinery were inspected, with T&H Lemont/Roll-Kraft as tooling and education benchmarks. Google/Bing responses did not provide reliable tube-mill ranking evidence; search volumes and worldwide positions were not measured. Competitor claims are not specifications for Gagan.

Do not deploy the keyword library, research, strategy or editorial notes as public website pages. Do not publish customer quotations or private customer data. The earlier technical SEO-fixes package remains separate.
