# Tube-mill SEO and competitor strategy for Gagan Engineering Works

Prepared 8 October 2026 for India and export buyers. Objective: grow qualified organic enquiries for verified tube-mill configurations, beginning with the 1.5-inch versus 3-inch OD-label decision. Worldwide number-one visibility is a long-term ambition, not a result this package can guarantee.

## Evidence and limits

This research inspected direct public manufacturer pages from Rollform, Fives, Formtek and FD Machinery, plus tooling/education resources from T&H Lemont and Roll-Kraft. Source URLs and access records are in `research-sources.json`. Only Rollform was verified as an Indian manufacturer in this review; the international benchmarks broaden the comparison, not the Indian census.

Google India/US requests produced retry pages or rate limits rather than reliable organic results. A Bing response was irrelevant to the tube-mill query. No ranking positions, traffic, search volumes, keyword difficulty or conversion rates have been measured. Manufacturer statements describe their own equipment; they are not independent tests or Gagan specifications. Content gaps below concern the reviewed pages, not entire companies.

The owner has confirmed that the 1.5-inch and 3-inch labels refer to OD and that round, square and rectangular configurations can be customized. The quotation, original images and running footage have not arrived. The draft deliberately leaves out unconfirmed machine ranges, thicknesses, materials, welding technology, prices, performance and certifications.

A live public catalogue snapshot returned 13 products and no product named as a tube mill or double-deck roofing machine. Recheck production before creating pages; new database records may appear later. The previously prepared technical SEO patch has not been verified as deployed during this research.

## How to compete with the inspected content

| Reviewed benchmark | Observable strength / page-specific gap | Gagan action | Proof needed | Measure |
|---|---|---|---|---|
| [Rollform carbon-steel mills](https://www.rollformindia.com/tube_mills_for_carbon_steel.html) | Model OD/thickness/speed table and equipment scope. The reviewed overview lacks a dedicated 38.1 mm versus 76.2 mm selection worksheet and product-specific accepted-output trial record. | Publish a clear model matrix and an OD-label comparison with an itemized RFQ worksheet. | Approved shape-size-wall-material combinations and base/optional scope. | Relevant model-query impressions and qualified specification enquiries. |
| [Fives OTO](https://www.fivesgroup.com/steel/tube-mills/oto-tube-mills) | Explains and links complete-line subsystems and forming technologies. The reviewed overview is broader than the proposed small-mill comparison. | Connect a tube-mill hub, genuine model pages and one focused comparison article; explain the proposed line stages. | Actual line diagram and supplied process, rather than borrowed features. | Indexable pages, internal-link coverage and enquiry paths from the hub/article. |
| [Formtek tube/pipe solutions](https://www.formtekgroup.com/solutions/tube-and-pipe-mills/) | Relates equipment and welding choices to applications and engineering/service scope. | Answer what the customer's finished product needs; publish a documented Gagan application or trial when available. | Real material/product, configuration, measured results and permission to publish. | Application-query impressions and enquiries specifying the finished product. |
| [FD high-speed ERW mill](https://www.fdmachinery.com/equipment/tube-and-pipe-mills/high-speed-erw-mill) | The reviewed 3-inch page states speed without associated thickness, material, sustained run duration or accepted output. | Put test conditions beside any Gagan speed/output claim. | Identified material, dimensions, wall, speed method, duration, accepted output and rejects. | Trial-video engagement, worksheet use and production-target enquiries. |
| [FD direct forming](https://www.fdmachinery.com/equipment/tube-and-pipe-mills/cfs-square-rectangular-directly-forming-mill) | Distinguishes direct square/rectangular forming from other routes. | Explain the actual Gagan forming route and tooling/changeover requirements after engineering review. | Confirmed process and tooling schedule. | Shape-selection queries and correctly specified RFQs. |
| [Roll-Kraft resources](https://www.roll-kraft.com/) and [T&H mill rolls](https://thlemont.com/products/tube-pipe-mill-rolls/) | Established technical resources, tooling explanations, training and calculators. These are tooling/content benchmarks, not automatically direct complete-mill competitors. | Produce original buyer tools and measured setup/changeover evidence; avoid another generic keyword article. | Gagan procedure, original media and checked calculations. | Useful referring links, resource downloads and relevant repeat visits. |

Do not turn this matrix into claims that competitors cannot supply a feature. Do not advertise faster output, cheaper equipment, better tolerances or superior support without a fair, documented comparison.

## Give each page a distinct job

- **Tube-mill hub:** own the broad manufacturer/category intent with the actual machine range, process options, support scope and links to models. Check for an existing live hub first.
- **1.5-inch model page:** own the verified configuration's machine/manufacturer/quotation queries. Publish the actual product matrix, supplied tooling, photographs and enquiry requirements.
- **3-inch model page:** own its genuinely different verified configuration. Avoid a near-copy with only the number changed.
- **This comparison article:** own `1.5 inch vs 3 inch tube mill` and the selection decision: OD, product mix, tooling, quotation scope, accepted output and ownership costs.
- **Media/watch page if justified:** make one original demonstration the main content, with transcript and context. An incidental video embedded in a blog is not automatically eligible for Google's video features.

Proposed model/hub URLs are planning choices, not existing pages. Establish actual URLs after reviewing the production database and product taxonomy. No broken or fabricated links should be published.

The new blog category can be `Tube Mills & Pipe Manufacturing` / `tube-mills` if implemented consistently in the API, frontend and admin filters. A product category is a separate taxonomy; do not reuse a blog slug blindly as a machine-category identifier.

## Use the 1,148-query map correctly

`keyword-map.csv` contains 1,148 distinct generated candidate queries, not 1,148 measured opportunities. `keyword-priorities.md` selects 50 initial priorities and assigns the page intent. Most synonymous candidates should share one useful answer/page; the map is not a site-generation plan.

Validate demand and intent with Search Console, buyer enquiry language, current country-specific results and a reputable keyword dataset. Record the source/date/market for any measured volume. Remove welding/material/equipment-option candidates that do not match confirmed Gagan capabilities. Prefer a smaller set with evidence to an arbitrary coverage count.

Use natural terms in the title, relevant headings, explanatory tables, captions and answers. Never paste the query library into body copy, hidden text, schema, alt text, a country list or a meta-keywords tag. [Google's spam policies](https://developers.google.com/search/docs/essentials/spam-policies#keyword-stuffing) describe unnatural keyword repetition as keyword stuffing. [Google's supported-tag guidance](https://developers.google.com/search/docs/crawling-indexing/special-tags) says meta-keywords have no effect on Google indexing or ranking.

## Make the manufacturer's evidence visible

The strongest next addition is one real Gagan configuration and trial, not another thousand phrases.

1. Review the quotation. Identify which model/configuration it covers, included and optional equipment, approved sizes and material limits. A quotation for one configuration is not a specification for both models.
2. Photograph the actual machine and finished samples. Show the relevant forming/tooling, process and cutoff, with accurate captions. Do not infer a welding technology or capacity from a photograph.
3. Record a production trial. Pair footage with material identification, measured dimensions/thickness, speed measurement, productive duration, accepted quantity and rejects. Redact private customer/contact/pricing information.
4. Explain changeover when useful. Define the start/end points, staffing and when accepted production resumes; a short edited clip cannot establish a measured changeover time.
5. Offer the RFQ and trial worksheets packaged here. They let a buyer define requirements and compare offers without assuming all line equipment is included.

Use genuine author/reviewer attribution and an actual publication date. Technical review is a quality control step, not a credential to invent. A customer story needs permission and identifiable evidence; anonymize it honestly if needed rather than fabricating a testimonial.

## Technical and structured-data requirements

Confirm the earlier SEO/publishing fixes are deployed before relying on them. Test the new article as a normal reader and crawler: full text/tables/FAQs, matching canonical and content, published state, internal links and status codes. The checked frontend section renderer shows Markdown as literal text, so make the new article's links genuinely clickable using safe formatting rather than assuming source Markdown already creates anchors. Check an unknown URL and configured database-error behavior. The existing dynamic browser missing-page HTTP 200 limitation still needs architectural work; do not call that solved by this content package.

Use one indexable canonical article, a descriptive title and summary, working breadcrumbs and a truthful `BlogPosting`/`Article` record. Dates must be real publication/edit dates; `lastmod` should change only for meaningful content changes. Author and image fields must reflect supplied facts/assets. Structured data must match visible content and does not guarantee a rich result.

Keep FAQs visible for buyers. Current [Google documentation updates](https://developers.google.com/search/updates#removing-faq-rich-result) state that FAQ rich results stopped appearing from **7 May 2026** and their documentation was removed. Do not sell FAQPage markup as a ranking/rich-result shortcut, and do not repeat older health/government-only eligibility guidance.

When footage arrives, use a real title, thumbnail, caption/transcript, upload date and accessible URL. Add `VideoObject` only with valid supported fields matching the actual video. [Google's video guidance](https://developers.google.com/search/docs/appearance/video) requires an indexed watch page where the video is the main content for video-feature eligibility; even that does not guarantee video indexing.

Optimize actual media delivery: suitable image formats/sizes, explicit dimensions, useful alt text, mobile readability and an accessible player. Preserve necessary consent and accessibility behavior. Performance should be measured on the deployed page instead of inferred from a successful local build.

The 1,148-query CSV and editorial/research documents are internal planning files. Do not deploy them as pages, sitemap entries or crawlable keyword dumps. Static `llms.txt`/`llms-full.txt` entries may be updated for consistency if the application uses them; do not promise Google rankings from those files.

## India and export strategy

Start with the English hub/model/comparison pages serving real Indian and export procurement questions. Clarify OD in mm and inches, utilities, packing, commissioning and documented contractual scope. Do not advertise named overseas installations or worldwide on-site service without evidence.

Choose the first export countries using actual enquiries, service/logistics capability and Search Console country/query data. Audit each selected market's intent and language; there is no single worldwide search-result order. Translate/localize only when the business can support the audience and the page offers useful localized procurement information. Use correct reciprocal hreflang for real equivalent language/region pages, following [Google's multilingual guidance](https://developers.google.com/search/docs/specialty/international/managing-multi-regional-sites). Avoid thin pages made by substituting country/city names.

Publish original videos on the business's legitimate channel and connect them to the relevant site page when assets are approved. Useful RFQ/trial resources can earn editorial references from genuine customers, technical publications and industry associations. Outreach, customer contact and external posting need separate explicit authorization; no outreach is performed by this package. Avoid bought links, fake reviews or guaranteed-ranking schemes.

## First 90 days: actions, not a ranking promise

| Window | Deliverable | Completion evidence |
|---|---|---|
| First 30 days | Review quotation/media, verify technical fixes, establish actual model/hub pages, publish reviewed comparison with worksheets and working enquiry path. | Accurate specifications, successful build/render checks, live indexable canonical, working downloads and real accepted-enquiry events. |
| Days 31–60 | Add one documented trial/video and an authentic configuration example; collect buyer questions and Search Console data; improve answers where intent is clear. | Published evidence, indexing observation, query/page/country baseline and classified qualified RFQs. |
| Days 61–90 | Choose one distinct follow-up resource from real demand: tooling/changeover, accepted-output planning or FAT; prioritize export localization only when supported. | A resource answering a different buyer question, useful internal links, demand evidence and monitored enquiry quality. |

Track separately: impressions, clicks, query/page/country CTR, Search Console average position, qualified RFQs, accepted enquiries and downstream sales outcomes. Average position is an aggregate, not a guaranteed rank for every searcher. Exclude staff/tests/spam where practical. A failed enquiry submission must never count as a confirmed lead.

Record worksheet downloads and actual video engagement separately from enquiries, using the site's existing analytics and required consent; do not introduce unapproved tracking IDs or third-party cookies. Set a baseline first. Review at least monthly, with action based on real intent and conversion evidence rather than a promised number-one date.
