# Tube-mill keyword priorities and publication rules

Prepared 8 October 2026 for Gagan Engineering, India and genuine export enquiries.

The CSV contains **1,148 distinct generated candidate queries** across 19 buyer-topic clusters. These are planning hypotheses, not search-demand research. No search volumes, keyword difficulty scores, SERP rankings or conversion estimates have been measured. Every row carries that limitation and a capability-review status.

The owner confirmed that 1.5 inch and 3 inch refer to outside diameter, and that square, round and rectangular configurations can be customised. No minimum/maximum size range, thickness range, material compatibility, welding method, tested speed, included equipment or performance guarantee has been verified here. Questions about those subjects do not imply the machines provide them. Review the forthcoming quotation/PDF and production evidence before adding machine-specific claims.

## How to use the map

- Give the comparison article one clear purpose: help buyers choose a 1.5-inch or 3-inch OD-labelled line using their actual product specification and acceptance requirements.
- Use a small selection of these terms naturally where the article answers the question. Do not target a keyword density or force every phrase into the copy.
- Commercial machine/manufacturer/price enquiries belong primarily on verified product/category pages and the RFQ flow. The article explains selection and links to those pages.
- Group related questions into one table or section. Do not generate 1,000 pages, duplicate FAQs, repetitive headings, hidden text, meta-keyword lists or keyword-filled image captions.
- P1 means editorial priority for this project, not a prediction of Google demand or ranking ease. P2/P3 are expansion and validation priorities, not publication requirements.
- Validate terms using Search Console impressions/query data, actual enquiry language and an appropriate keyword tool. Record geography, date, volume-source and SERP intent before promoting a candidate to a measured target.
- Use each image alt attribute to describe the actual image. Use a video caption/transcript to describe the demonstrated configuration and tested conditions. Do not use media text as a keyword dump.

## Fifty curated priorities

| Candidate query | Intended owner | Use / review condition |
| --- | --- | --- |
| 1.5 inch vs 3 inch tube mill | Comparison blog | Explain the selection decision; verify claims |
| 1.5 inch tube mill buying guide | Comparison blog | Explain the selection decision; verify claims |
| 3 inch tube mill buying guide | Comparison blog | Explain the selection decision; verify claims |
| how to choose between a 1.5 inch and 3 inch tube mill | Comparison blog | Explain the selection decision; verify claims |
| 1.5 inch tube mill machine | Model product / RFQ | Explain the selection decision; verify claims |
| 3 inch tube mill machine | Model product / RFQ | Explain the selection decision; verify claims |
| tube mill machine manufacturer in India | Category / product | Explain the selection decision; verify claims |
| tube mill machine manufacturer for export | Category / product | Confirm destination requirements and contract scope |
| 1.5 inch tube mill outside diameter meaning | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| 3 inch tube mill outside diameter meaning | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| tube mill OD versus nominal pipe size | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| 1.5 inch OD in mm | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| 3 inch OD in mm | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| 1.5 inch tube mill wall thickness specification checklist | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| 3 inch tube mill wall thickness specification checklist | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| tube mill OD and wall thickness combination limits | Comparison blog | Distinguish OD labels from a verified size/thickness matrix |
| tube mill round square rectangular configuration | Comparison blog | Confirm exact profiles, dimensions and tooling in the quotation |
| 1.5 inch tube mill square tube size range questions | Comparison blog | Confirm exact profiles, dimensions and tooling in the quotation |
| 3 inch tube mill rectangular tube size range questions | Comparison blog | Confirm exact profiles, dimensions and tooling in the quotation |
| tube mill square tube tooling requirements | Comparison blog | Confirm exact profiles, dimensions and tooling in the quotation |
| tube mill rectangular tube tooling requirements | Comparison blog | Confirm exact profiles, dimensions and tooling in the quotation |
| tube mill compatible materials to confirm | Comparison blog | Confirm grades, strength, coating and welding compatibility |
| tube mill steel grade requirements for quotation | Comparison blog | Confirm grades, strength, coating and welding compatibility |
| tube mill welding method confirmation | Comparison blog | Publish the actual supplied process only after PDF review |
| tube mill complete roll set inclusion checklist | Comparison blog | Define supplied roll sets and priced extras |
| tube mill profile changeover process | Comparison blog | Explain procedure; quantify only from a recorded trial |
| tube mill rated speed versus production speed | Comparison blog | State trial size, thickness, material, cut length and saleable output |
| tube mill speed by size and thickness | Comparison blog | State trial size, thickness, material, cut length and saleable output |
| tube mill saleable output calculation | Comparison blog | State trial size, thickness, material, cut length and saleable output |
| 1.5 inch tube mill price quotation request | Model product / RFQ | Explain cost drivers; avoid invented list prices |
| 3 inch tube mill price quotation request | Model product / RFQ | Explain cost drivers; avoid invented list prices |
| tube mill quotation inclusion checklist | Model product / RFQ | Explain cost drivers; avoid invented list prices |
| tube mill mechanical line price versus complete line | Model product / RFQ | Explain cost drivers; avoid invented list prices |
| tube mill extra roll set price request | Model product / RFQ | Explain cost drivers; avoid invented list prices |
| tube mill factory floor space requirements | Comparison blog | Use the approved load schedule and layout |
| tube mill installed power versus running load | Comparison blog | Use the approved load schedule and layout |
| tube mill voltage and frequency requirements | Comparison blog | Use the approved load schedule and layout |
| tube mill running cost calculation | Comparison blog | Show a transparent method with buyer-entered inputs |
| tube mill production cost worksheet | Comparison blog | Show a transparent method with buyer-entered inputs |
| tube mill return on investment assumptions | Comparison blog | Show a transparent method with buyer-entered inputs |
| tube mill factory acceptance test checklist | Comparison blog | Use a written test plan and real measured evidence |
| tube mill buyer material production trial | Comparison blog | Use a written test plan and real measured evidence |
| tube mill production speed trial evidence | Comparison blog | Use a written test plan and real measured evidence |
| tube mill weld quality trial evidence | Comparison blog | Use a written test plan and real measured evidence |
| tube mill critical spare parts list | Product specification | State verified scope, parts and responsibilities |
| tube mill commissioning responsibility checklist | Product specification | State verified scope, parts and responsibilities |
| tube mill export quotation checklist | Existing export guide / product | Confirm destination requirements and contract scope |
| tube mill overseas commissioning requirements | Existing export guide / product | Confirm destination requirements and contract scope |
| tube mill manufacturer factory verification | Comparison blog | Use genuine machine, factory and production evidence |
| tube mill quotation claim verification | Comparison blog | Use genuine machine, factory and production evidence |

## Article terms versus product-page terms

For the proposed article, the central phrase is **1.5 inch vs 3 inch tube mill**. Closely related concepts are buying guide, outside diameter, wall thickness, round/square/rectangular configuration, tooling, tested production speed, cost factors and factory acceptance test. These are topics to answer, not phrases that must be repeated verbatim.

For product pages, verify the existing machine URLs before mapping **1.5 inch tube mill machine**, **3 inch tube mill machine**, manufacturer, export and price/RFQ enquiries. Match a query to the most useful canonical page. Do not make the article and product page compete with identical titles, metadata and copied specifications.

## Existing content and internal linking

The checked repository already contains the export guide `/blog/industrial-machinery-export-guide-india`, the decoiler guide `/blog/10-ton-hydraulic-decoiler-guide`, the CTL guide `/blog/automatic-cut-to-length-ctl-line-guide`, and the pipe-end guide `/blog/pipe-counter-boring-and-facing-machine-guide`. Use them only where the buyer question actually relates to that process. A CTL sheet line and pipe-end finishing equipment are separate equipment scopes; do not imply they are included in a tube mill.

The new article should explain tube-specific coil loading, commissioning and documentation briefly, then link to the existing guides where appropriate. Do not create new general export, decoiler or pipe-end articles merely to house more variants.

## Candidate construction and review

The pool uses 380 hand-curated buyer-topic phrases, each expanded into one generic tube-mill query and the two owner-confirmed OD-label contexts. Fifty curated priorities are then added or promoted, deduplicating case-insensitively. This limited expansion captures model-specific procurement questions without inventing sizes, capacities, countries or demand. Similar queries deliberately share one page/section recommendation.

Technical-option queries such as HF/TIG welding, direct forming, bead removal, automatic controls, cold saws and testing equipment remain **questions to check**, not Gagan sales claims. Remove irrelevant candidates after the quotation is reviewed. Keep this CSV outside public article copy, sitemap, structured data, title tags, description tags and alt text.
